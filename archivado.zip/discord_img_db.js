


/*

var Discord = require('discord.js');
var bot = new Discord.Client();

const fs = require('fs');
const path = require("path");
require('dotenv').config();
//const bodyParser = require('body-parser');

const express = require('express')
const app = express()
var channel

//app.use(bodyParser.urlencoded({ extended: true }));

app.listen(process.env.PORT || 3009, function(){
    console.log('-')
    console.log('-')
    console.log('-')
    console.log('-')
    console.log('-')
    console.log('-')
    console.log('-')
    console.log('-')
    console.log('-')
    console.log('-')
    console.log('-')
    console.log('-')
    console.log('-')
	console.log("Server on");
});




app.get('/', function(req, res) {
    console.log('ola')
    res.send('que ace ak gato?')
});


bot.on('ready', client => {
    channel =  bot.channels.cache.get('735124659233882150')
})

bot.on('message', message => {
    //console.log(message.channel.send)
    channel.send('Message that goes above image', {
        files: [
            "./img.jpeg"
        ]
    });
});

bot.login(process.env.DISCORD_TOKEN);












const multer = require("multer");

const handleError = (err, res) => {
  res
    .status(500)
    .contentType("text/plain")
    .end("Error!");
};

const upload = multer({
  dest: "/path/to/temporary/directory/to/store/uploaded/files"
  // you might also want to set some limits: https://github.com/expressjs/multer#limits
});

app.get("/", express.static(path.join(__dirname, "./public")));

app.post(
  "/upload",
  upload.single("file"),
  (req, res) => {
    const tempPath = req.file.path;
    const targetPath = path.join(__dirname, "./uploads/image.png");

    if (path.extname(req.file.originalname).toLowerCase() === ".png") {
      fs.rename(tempPath, targetPath, err => {
        if (err) return handleError(err, res);

        res
          .status(200)
          .contentType("text/plain")
          .end("File uploaded!");
      });
    } else {
      fs.unlink(tempPath, err => {
        if (err) return handleError(err, res);

        res
          .status(403)
          .contentType("text/plain")
          .end("Only .png files are allowed!");
      });
    }
  }
);


















function readFile(srcPath) {
    return new Promise(function (resolve, reject) {
        fs.readFile(srcPath, 'utf8', function (err, data) {
            if (err) {
                reject(err)
            } else {
                resolve(data);
            }
        });
    })
}

function writeFile(savPath, data) {
    return new Promise(function (resolve, reject) {
        fs.writeFile(savPath, data, function (err) {
            if (err) {
                reject(err)
            } else {
                resolve();
            }
        });
    })
}

*/

var fs = require('fs')
var Multer = require('multer')
var path = require('path')
var config = require('./../../config')  //configuration file to get project root path
//name of the input type (avatar in our case).
const FILENAME = 'avatar';

const uploadDir = config.get('path_project') + '/' +'uploads/';
if (!fs.existsSync(uploadDir)) {
    fs.mkdirSync(uploadDir);
}

/**
*	multer setting for photo upload storage and imagename setting, also
*	set the file details in request object
*/
let photoStorage = Multer.diskStorage({
    destination: function (req, file, cb) {
       cb(null, uploadDir)
   },
   filename: function (req, file, cb) {
        cb(null, "Photo" + '_' + Date.now() + path.extname(file.originalname));
   }
})

/**
*	Function to set storage for single upload, named as FILENAME
*/
let singleFileUpload = () => {
    return Multer({
        storage : photoStorage
    }).single(FILENAME);
}

function controller(req, res) {
    /**
    *   You will get image details in req.file (path where image is saved and name of the image), and if you send any other data you will get it in req.body.
    */
        localPath = req.file.destination;
        filename = req.file.filename;
    }